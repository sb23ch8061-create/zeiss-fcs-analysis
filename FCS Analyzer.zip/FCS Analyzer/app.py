import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
import io
from read_zeiss import load_zeiss
from fit_models import fit_standard, fit_triplet
from export_results import results_to_dataframe
from statistics import summarize

# Configure the page
st.set_page_config(page_title="FCS Real-Time Analysis", layout="wide")
st.title("Zeiss LSM980 FCS Real-Time Dashboard")

# Initialize session state for Omega Squared (Stored strictly in µm²)
if "omega_sq" not in st.session_state:
    st.session_state.omega_sq = 0.042

# 1. Load Data (Cached so it only reads the file once)
@st.cache_data
def get_data(filename):
    try:
        return load_zeiss(filename)
    except Exception as e:
        st.error(f"Error reading file: {e}")
        return None

datasets = get_data("S1.txt")

if datasets:
    # 2. Sidebar for Real-Time Controls
    st.sidebar.header("Fit Parameters")
    
    # Expanded slider range
    s_value = st.sidebar.slider("Structure Parameter (S)", min_value=1.0, max_value=10.0, value=7.5, step=0.1)
    
    # Toggle between models
    model_choice = st.sidebar.radio("Select Model", ["Standard 3D", "Triplet 3D"])
    
    # Multiselect Toolbar for selecting custom repetitions
    rep_options = [f"Rep{i+1:02d}" for i in range(20)]
    selected_reps = st.sidebar.multiselect(
        "Select Repetitions to Compare", 
        options=rep_options, 
        default=["Rep01"]
    )
    
    # NEW COMPONENT: Confocal Parameter Calculation
    st.sidebar.divider()
    st.sidebar.subheader("Confocal Parameter Calculation (ω²)")
    
    with st.sidebar.expander("Open Calculation Window"):
        # Added format="%.10f" to allow up to 10 decimal points for precision inputs
        d_val = st.number_input("Diffusivity (D)", value=400.0, format="%.10f", step=1e-5)
        d_unit = st.selectbox("Unit for D", ["µm²/s", "cm²/s"])
        
        tau_val = st.number_input("Diffusion Time (τD)", value=25.0, format="%.10f", step=1e-5)
        tau_unit = st.selectbox("Unit for τD", ["µs", "ms", "s"])
        
        out_unit = st.selectbox("Output Unit for ω²", ["µm²", "cm²"])
        
        if st.button("Calculate ω²"):
            # STRICT UNIT CONVERSION: Convert D strictly to µm²/s
            if d_unit == "µm²/s":
                d_um2 = d_val 
            elif d_unit == "cm²/s":
                d_um2 = d_val * 1e8  # 1 cm² = 10^8 µm²
                
            # STRICT UNIT CONVERSION: Convert τD strictly to seconds
            if tau_unit == "µs": 
                t_s = tau_val * 1e-6
            elif tau_unit == "ms": 
                t_s = tau_val * 1e-3
            elif tau_unit == "s":
                t_s = tau_val
            
            # Math: ω² = 4 * D * τD (Resulting unit is fundamentally µm²)
            w2_um2 = 4 * d_um2 * t_s
            st.session_state.omega_sq = w2_um2
            
        # Display current active value
        current_w2 = st.session_state.omega_sq
        display_w2 = current_w2 if out_unit == "µm²" else current_w2 * 1e-8
        st.success(f"Current ω²: {display_w2:.6e} {out_unit}")
        st.caption("This value will be used dynamically in the statistics panel.")
    
    # 3. Process Data dynamically based on S (Truncated at tau >= 1e-6)
    results = {} 
    
    with st.spinner("Fitting data from 10^-6s onwards..."):
        for i in range(20):
            name = f"Rep{i+1:02d}"
            tau = np.array(datasets[name]["tau"])
            G = np.array(datasets[name]["G"])
            
            mask = tau >= 1e-6
            tau_fit = tau[mask]
            G_fit = G[mask]
            
            if model_choice == "Standard 3D":
                res = fit_standard(tau_fit, G_fit, S=s_value)
            else:
                res = fit_triplet(tau_fit, G_fit, S=s_value)
                
            results[name] = res
            
        avg_tau = np.array(datasets["Average"]["tau"])
        avg_G = np.array(datasets["Average"]["G"])
        
        avg_mask = avg_tau >= 1e-6
        avg_tau_fit = avg_tau[avg_mask]
        avg_G_fit = avg_G[avg_mask]
        
        if model_choice == "Standard 3D":
            avg_res = fit_standard(avg_tau_fit, avg_G_fit, S=s_value)
        else:
            avg_res = fit_triplet(avg_tau_fit, avg_G_fit, S=s_value)
            
    # 4. Display Graphs side-by-side
    col1, col2 = st.columns(2)
    
    # LEFT PANEL: Global Average Dataset
    with col1:
        st.subheader("Average Curve Fit & Residuals")
        fig1, (ax1, ax2) = plt.subplots(2, 1, figsize=(6, 5), sharex=True, gridspec_kw={'height_ratios': [3, 1]})
        
        ax1.semilogx(avg_tau, avg_G, "o", ms=4, label="Experiment (Avg)", color="gray", alpha=0.3)
        ax1.semilogx(avg_tau_fit, avg_res["fit"], "-", lw=2, label=f"Fit (S={s_value})", color="red")
        ax1.set_ylabel("G(tau)")
        ax1.legend()
        ax1.grid(True, which="both", ls="--", alpha=0.3)
        
        residuals = avg_G_fit - avg_res["fit"]
        ax2.semilogx(avg_tau_fit, residuals, "-", color="blue", lw=1.2)
        ax2.axhline(0, color="black", linestyle="--", alpha=0.7)
        ax2.set_xlabel("Lag time (s)")
        ax2.set_ylabel("Residuals")
        ax2.grid(True, which="both", ls="--", alpha=0.3)
        
        plt.tight_layout()
        st.pyplot(fig1)
        
        # Save figure 1 to buffer for download
        buf1 = io.BytesIO()
        fig1.savefig(buf1, format="png", dpi=300, bbox_inches='tight')
        buf1.seek(0)
        
    # RIGHT PANEL: Selected repetition tracesdth
    with col2:
        st.subheader("Selected Repetition Fit & Residuals")
        buf2 = None
        
        if selected_reps:
            fig2, (rax1, rax2) = plt.subplots(2, 1, figsize=(6, 5), sharex=True, gridspec_kw={'height_ratios': [3, 1]})
            
            for rep_name in selected_reps:
                rep_tau = np.array(datasets[rep_name]["tau"])
                rep_G = np.array(datasets[rep_name]["G"])
                rep_mask = rep_tau >= 1e-6
                rep_tau_fit = rep_tau[rep_mask]
                rep_G_fit = rep_G[rep_mask]
                rep_res = results[rep_name]
                
                line_match = rax1.semilogx(rep_tau, rep_G, "o", ms=3, alpha=0.25)
                active_color = line_match[0].get_color()
                
                rax1.semilogx(rep_tau_fit, rep_res["fit"], "-", lw=1.5, color=active_color, label=f"{rep_name} Fit")
                rep_residuals = rep_G_fit - rep_res["fit"]
                rax2.semilogx(rep_tau_fit, rep_residuals, "-", lw=1.2, color=active_color)
            
            rax1.set_ylabel("G(tau)")
            rax1.legend(fontsize='small', loc='upper right', ncol=2 if len(selected_reps) > 4 else 1)
            rax1.grid(True, which="both", ls="--", alpha=0.3)
            
            rax2.axhline(0, color="black", linestyle="--", alpha=0.7)
            rax2.set_xlabel("Lag time (s)")
            rax2.set_ylabel("Residuals")
            rax2.grid(True, which="both", ls="--", alpha=0.3)
            
            plt.tight_layout()
            st.pyplot(fig2)
            
            # Save figure 2 to buffer for download
            buf2 = io.BytesIO()
            fig2.savefig(buf2, format="png", dpi=300, bbox_inches='tight')
            buf2.seek(0)
        else:
            st.info("Please select one or more repetitions from the sidebar panel to render comparative graphs.")

    st.divider()

    # 5. Display Comprehensive Summary Statistics
    st.subheader("Summary Statistics")
    
    # Isolate Diffusion Times (Results natively output τD in seconds)
    tauD_sec_list = np.array([r["tauD"] for r in results.values()])
    tauD_us_list = tauD_sec_list * 1e6
    
    # Calculate Array of Diffusivities (D = ω² / (4 * τD))
    D_list = st.session_state.omega_sq / (4 * tauD_sec_list)
    
    # Average and Std Calculations for Diffusion Time
    avg_tauD_us = np.mean(tauD_us_list)
    std_tauD_us = np.std(tauD_us_list)
    
    # Average and Std Calculations for Diffusivity
    avg_D = np.mean(D_list)
    std_D = np.std(D_list)
    
    # Display metrics across 2 columns (Merged Avg & Std)
    metric_col1, metric_col2 = st.columns(2)
    with metric_col1:
        st.metric(label="Overall Avg. Diffusion Time (τD) ± σ", value=f"{avg_tauD_us:.2f} ± {std_tauD_us:.2f} µs")
    with metric_col2:
        st.metric(label="Overall Avg. Diffusivity (D) ± σ", value=f"{avg_D:.6f} ± {std_D:.6f} µm²/s")
        
    # Append Diffusivity D for each individual rep to the DataFrame
    df_results = results_to_dataframe(list(results.values()))
    df_results["Diffusivity D (µm²/s)"] = D_list
    
    st.dataframe(df_results, height=500, use_container_width=True)

    st.divider()

    # 6. Save Option Section
    st.subheader("💾 Save & Export Analysis")
    st.write(f"Parameters: Structure Parameter **S = {s_value}** | Confocal Parameter **ω² = {st.session_state.omega_sq:.6f} µm²**")
    
    save_name = st.text_input("Filename Prefix:", value="FCS_Data")
    
    dl_col1, dl_col2, dl_col3 = st.columns(3)
    
    with dl_col1:
        csv_data = df_results.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📊 Download Statistics (CSV)",
            data=csv_data,
            file_name=f"{save_name}_S{s_value}.csv",
            mime='text/csv'
        )
        
    with dl_col2:
        st.download_button(
            label="📈 Download Average Fit Graph",
            data=buf1,
            file_name=f"{save_name}_AvgFit_S{s_value}.png",
            mime='image/png'
        )
        
    with dl_col3:
        if buf2 is not None:
            st.download_button(
                label="📉 Download Repetition Graph",
                data=buf2,
                file_name=f"{save_name}_Reps_S{s_value}.png",
                mime='image/png'
            )